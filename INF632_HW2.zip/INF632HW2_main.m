%*********************************************************************
% Daniela Hernández
% INF632 - 002
% HW2: Basic Statistical Tests
% Due: February 19, 2026

% Purpose: Display ability to perfom statitical tests on a collection
% of data sets.

% *I was not able to answer all the HW questions*
%*********************************************************************

% make sure the workspace is clean
clc
clear

% ask the user how many/which file(s) they want to use
numFiles = input('How many files do you want to load? ');
data = cell(1, numFiles);

for i = 1:numFiles
    filename = input(['Enter filename #' num2str(i) ': '], 's');
    
    % read data from file, skipping first header line
    raw = readmatrix(filename, 'NumHeaderLines', 1);
    
    % store data as row averages (average across all columns except first)
    data{i} = mean(raw(:,2:end), 2);
end

% harmonic mean, arithmetic mean, and variance
for i = 1:numFiles
    dataset = data{i}(:);
    dataset = dataset(~isnan(dataset));
    hm = harmonic_mean(dataset);
    am = mean(dataset, 'omitnan');
    vx = var(dataset, 0, 'omitnan');
    
    fprintf('\nHarmonic Mean: %.4f\n', hm);
    fprintf('Arithmetic Mean: %.4f\n', am);
    fprintf('Variance: %.4f\n\n', vx);
end

% explanation of why harmonic mean is smaller than arithmetic mean
fprintf(['The harmonic mean is much smaller than the arithmetic' ...
        [' mean because\nit is pulled down by minutes with' ...
        [' few or zero steps, while the\narithmetic mean is inflated' ...
         ' by occasional large step counts.\n\n']]])

% explanation of why variance is large
fprintf(['The variance is large because the step counts are very uneven, ' ...
    'with \nmany minutes having very few or zero steps and some minutes ' ...
    'having \nvery high steps.\n\n'])

% pooled standard deviation for first two datasets if available
if numFiles >= 2
    psd = pooled_sd(data{1}, data{2});
    fprintf('Pooled Standard Deviation: %.4f\n\n', psd);
end

% t-test for first two datasets if available
if numFiles >= 2
    [t, p] = t_test(data);
    fprintf('t-value: %.4f\n', t);
    if p < 1e-10
        fprintf('p-value < 1e-10\n');
    else
        fprintf('p-value: %.6f\n\n', p);
    end
end

fprintf('\nSince the p-value is small, we know the step counts are different.\n')

% ANOVA across all datasets if at least 3 datasets
if numFiles >= 3
    [F, p] = anova(data);
    fprintf('\nF-statistic: %.4f\n', F);
    if p < 1e-10
        fprintf('p-value < 1e-10\n');
    else
        fprintf('p-value: %.6f\n\n', p);
    end
end

% compute daily totals for each day of the week
dailyData = cell(1,7); 
for d = 1:7
    dailyData{d} = [];  % initialize empty
    for f = 1:numFiles
        % sum steps for each day (assuming 24 steps per day)
        idx = (d-1)*24+1 : min(d*24, length(data{f})); 
        dailyData{d} = [dailyData{d}; sum(data{f}(idx))];
    end
end

% print daily step totals for each day of the week
fprintf('\nDaily step totals for each day of the week:\n');
for d = 1:7
    fprintf('Day %d: ', d)
    fprintf('%.0f ', dailyData{d})
    fprintf('\n')
end

fprintf('\nIt is clear they are not equally active on different days of the week.\n')

% repeated measures ANOVA across all datasets
if numFiles >= 2
    try
        [F_rm, p_rm] = rmanova(data);
        fprintf('\nRepeated Measures F-statistic: %.4f\n', F_rm);
        if p_rm < 1e-10
            fprintf('Repeated Measures p-value < 1e-10\n');
        else
            fprintf('Repeated Measures p-value: %.6f\n', p_rm);
        end
    catch ME
        fprintf('%s\n', ME.message);
    end
end