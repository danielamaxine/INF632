%*********************************************************************
% HARMONIC MEAN FUNCTION
%*********************************************************************
% anumerical average calculated by dividing the number of observations
% in a dataset by the sum of the reciprocals of those values
%*********************************************************************

function hm = harmonic_mean(dataset)

% convert dataset to a column vector
dataset = dataset(:);

% remove nans from dataset
dataset = dataset(~isnan(dataset));

% remove zeros from dataset (harmonic mean undefined for zero)
dataset = dataset(dataset ~= 0);

% count number of valid elements
n = length(dataset);

% sum of reciprocals of dataset
reciprocal_sum = sum(1 ./ dataset);

% compute harmonic mean
hm = n / reciprocal_sum;

end