%*********************************************************************
% REPEATED MEASURES ANOVA
%*********************************************************************
% this function performs a repeated measures ANOVA
% data must be a cell array where:
% each cell = one condition
% each condition contains the same number of subjects

% REFERENCE: https://www.youtube.com/watch?v=FIxzP4fmi3w
% REFERENCE: https://www.mathworks.com/help/matlab/ref/betainc.html
%*********************************************************************

function [F, p] = rmanova(data)

% get number of conditions
k = length(data);

% find smallest dataset length
minLen = min(cellfun(@length, data));

% truncate all datasets to same length
for j = 1:k
    data{j} = data{j}(1:minLen);
end

% number of subjects
n = minLen;

% combine all datasets into n x k matrix
X = zeros(n,k);
for j = 1:k
    X(:,j) = data{j}(:);
end

% compute overall mean
grand = mean(X(:));

% compute mean per condition
cond  = mean(X);

% compute mean per subject
subj  = mean(X,2);

% sum of squares for conditions
SSc = sum(n*(cond-grand).^2);

% sum of squares for subjects
SSs = sum((X-subj).^2,'all');

% sum of squares for error
SSe = SSs - SSc;

% DOF
dfc = k-1;
dfe = dfc*(n-1);

% mean squares
MSC = SSc/dfc;
MSE = SSe/dfe;

% F-statistic
F = MSC/MSE;

% p-value using inline beta series approximation
x = dfc*F / (dfc*F + dfe);
pval = 0; t = 1;
for m = 0:50
    t = t*(dfc/2+m)*x/(dfc/2 + dfe/2 + m);
    pval = pval + t/(m+1);
end
pval = 1 - pval * x^(dfc/2) * (1-x)^(dfe/2);

% clamp small p-values
if pval < 1e-10
    p = 1e-10; 
else
    p = pval;
end

end