%*********************************************************************
% T-TEST
%*********************************************************************
% this function computes the test statistic to compare means
% data must be a cell array containing at least two datasets

% REFERENCE: https://www.mathworks.com/help/matlab/ref/betainc.html
%*********************************************************************

function [t, p] = t_test(data)

% check that at least two datasets are provided
if length(data) < 2
    error('you must load at least two datasets.');
end

% convert first set to column vector
x1 = data{1}(:);

% convert second set to column vector
x2 = data{2}(:);

% remove nans from first set
x1 = x1(~isnan(x1));

% remove nans from second set
x2 = x2(~isnan(x2));

% get number of observations in first dataset
n1 = length(x1);

% get number of observations in second set
n2 = length(x2);

% DOF
df = n1 + n2 - 2;

% SD of each set
s1 = std(x1);
s2 = std(x2);

% PSD
sp = sqrt(((n1-1)*s1^2 + (n2-1)*s2^2)/df);

% t-statistic
t = (mean(x1) - mean(x2)) / (sp * sqrt(1/n1 + 1/n2));

% approximate t as z for large DOF
z = t / sqrt(df/(df-2));

% two-tailed p-value using error function
p = 2 * 0.5 * (1 - erf(abs(z)/sqrt(2)));

end