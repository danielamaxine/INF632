%*********************************************************************
% POOLED STANDARD DEVIATION
%*********************************************************************
% this function estimates the SD of multiple samples
% data must be a cell array of datasets
%*********************************************************************

function sp = pooled_sd(x1, x2)

% convert x1 to a column vector
x1 = x1(:);

% convert x2 to a column vector
x2 = x2(:);

% remove nans from x1
x1 = x1(~isnan(x1));

% remove nans from x2
x2 = x2(~isnan(x2));

% get number of observations in x1
n1 = length(x1);

% get number of observations in x2
n2 = length(x2);

% compute degrees of freedom for pooled standard deviation
df = n1 + n2 - 2;

% compute standard deviation of x1
s1 = std(x1);

% compute standard deviation of x2
s2 = std(x2);

% compute pooled standard deviation
sp = sqrt(((n1-1)*s1^2 + (n2-1)*s2^2) / df);

end