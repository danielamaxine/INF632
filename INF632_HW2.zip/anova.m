%*********************************************************************
% ONE-WAY ANOVA
%*********************************************************************
% Accepts a cell array of datasets (3 or more)
% Returns F-statistic and p-value

% REFERENCE: https://en.wikipedia.org/wiki/One-way_analysis_of_variance
%*********************************************************************

function [F, p] = anova(data)

% get the number of datasets (groups)
m = length(data);

% ensure there are at least 3 datasets for anova
if m < 3
    error('anova requires at least 3 datasets.');
end

% array to store all values combined
allValues = [];

% loop through each dataset to clean data and combine
for j = 1:m
    % convert dataset to column vector
    x = data{j}(:);
    
    % remove nans
    x = x(~isnan(x));
    
    % update cleaned dataset
    data{j} = x;
    
    % add cleaned data to combined array
    allValues = [allValues; x];
end

% overall mean of all observations
Xbar = mean(allValues);

% total number of observations
N = length(allValues);

% initialize sum of squares between groups
SSbetween = 0;

% loop over each group to compute sum of squares between
for j = 1:m
    % number of observations in group j
    nj = length(data{j});
    
    % mean of group j
    xbarj = mean(data{j});
    
    % add contribution of group j to SSbetween
    SSbetween = SSbetween + nj * (xbarj - Xbar)^2;
end

% total sum of squares
SStotal = sum((allValues - Xbar).^2);

% um of squares within groups
SSwithin = SStotal - SSbetween;

% DOF between groups
dfbetween = m - 1;

% DOF within groups
dfwithin = N - m;

% mean square between groups
MSbetween = SSbetween / dfbetween;

% mean square within groups
MSwithin = SSwithin / dfwithin;

% compute F-statistic
F = MSbetween / MSwithin;

% approximate p-value using the beta function
x = dfwithin / (dfwithin + dfbetween * F);
p = betainc(x, dfwithin/2, dfbetween/2);

end