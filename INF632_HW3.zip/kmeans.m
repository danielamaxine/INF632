function [clusters, centroids] = kmeans(X, k)
    maxIter = 100;
    n = size(X,1);
    centroids = X(randperm(n,k), :);  % random initialization
    clusters = zeros(n,1);
    
    for iter = 1:maxIter
        % Assign clusters
        for i = 1:n
            dists = sum((centroids - X(i,:)).^2, 2);
            [~, clusters(i)] = min(dists);
        end
        
        % Update centroids
        newCentroids = zeros(k, size(X,2));
        for j = 1:k
            pointsInCluster = X(clusters==j, :);
            if ~isempty(pointsInCluster)
                newCentroids(j,:) = mean(pointsInCluster, 1);
            else
                newCentroids(j,:) = X(randi(n), :); % random reinit empty cluster
            end
        end
        
        % Check convergence
        if all(newCentroids == centroids)
            break;
        end
        centroids = newCentroids;
    end
end