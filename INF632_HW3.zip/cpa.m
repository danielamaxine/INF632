function cps = cpa(x)
% find up to 8 change points in a time series using mean shift

% make column vector
x = x(:);

% initialize output
cps = [];

% maximum number of change points
maxCps = 8;

% recursive function to find change points
function findCp(xSegment, offset)
    % only continue if we want more cps
    if length(cps) >= maxCps || length(xSegment) < 2
        return
    end
    
    n = length(xSegment);
    bestDiff = 0;
    cpLocal = 1;
    
    % test each split
    for t = 2:n-1
        m1 = mean(xSegment(1:t));
        m2 = mean(xSegment(t+1:end));
        diff = abs(m1 - m2);
        if diff > bestDiff
            bestDiff = diff;
            cpLocal = t;
        end
    end
    
    % store cp relative to original series
    cps(end+1) = offset + cpLocal;
    
    % recursively find cps in left and right segments
    findCp(xSegment(1:cpLocal), offset);
    findCp(xSegment(cpLocal+1:end), offset + cpLocal);
end

% start recursion
findCp(x, 0);

% keep only first 8 cps and sort
cps = sort(cps(1:min(end,maxCps)));
end