function label = knn(trainX, trainY, testPoint, k)
    % Calculate Euclidean distances
    distances = sqrt(sum((trainX - testPoint).^2, 2));
    
    % Sort distances and get k nearest neighbors
    [~, sortedIdx] = sort(distances);
    
    % Exclude self if testPoint is identical to any train point
    if distances(sortedIdx(1)) == 0
        sortedIdx = sortedIdx(2:end);
    end
    
    nearestLabels = trainY(sortedIdx(1:k));
    
    % Majority vote
    label = mode(nearestLabels);
end