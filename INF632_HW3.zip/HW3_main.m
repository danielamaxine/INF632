%*********************************************************************
% Daniela Hernández
% INF632 - 002
% HW3: Statistical Learning & Prediction
% Due: March 19, 2026
%*********************************************************************

% make sure the workspace is clean
clc
clear

% ==========================================
% ASK USER FOR FILE
% ==========================================

filename = input('Enter CSV filename: ', 's');

% read data from file
X = readmatrix(filename);

% ==========================================
% K-MEANS CLUSTERING
% ==========================================

k_means = input('Enter number of clusters for K-means: ');
[clusters, centroids] = kmeans(X, k_means);

disp('K-means cluster assignments:');
disp(clusters);

% ==========================================
% KNN 
% ==========================================

% Split data into training and labels
trainX = X(:, 1:end-1);  % features
trainY = X(:, end);      % class labels

% Ask user for odd k
k_knn = input('Enter odd k for KNN (less than number of training points): ');
if mod(k_knn,2)==0
    k_knn = k_knn + 1; % make k odd
end
k_knn = min(k_knn, size(trainX,1)-1);

% Ask user for new point
newPoint = input('Enter new data point as row vector: ');

predictedClass = knn(trainX, trainY, newPoint, k_knn);
fprintf('Predicted class for new point: %d\n', predictedClass);

% ==========================================
% CHANGE POINT ANALYSIS
% ==========================================

% read csv as table to preserve dates
T = readtable(filename);

% convert first column to datetime
dates = datetime(T{:,1}, 'InputFormat', 'MM/dd/yyyy');

% extract daily steps from second column
ts = T{:,2};

% remove zero-step days
nonzeroIdx = ts ~= 0;
ts_nz = ts(nonzeroIdx);
dates_nz = dates(nonzeroIdx);

% run cpa to detect up to 8 change points
cp = cpa(ts_nz);

% convert change point indices to actual dates
cp_dates = dates_nz(cp);

% display detected change point indices
fprintf('\ndetected change point indices:\n');
disp(cp);

% display detected change point dates
fprintf('\ndetected change point dates:\n');
disp(cp_dates);

%based on the output,
%I can assume the first two and last spikes were due to the holiday 
%season and the others were during summer break